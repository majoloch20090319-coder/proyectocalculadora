/** Cliente de autenticación. Las cookies HttpOnly las gestiona Node.js. */
(function(){'use strict';
const $=id=>document.getElementById(id);
let current=null;
async function request(url,options={}){const res=await fetch(url,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...options});const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.error||'No se pudo completar la solicitud.');return data;}
async function logout(){try{await request('/api/logout',{method:'POST'});}finally{location.replace('/index.html');}}
window.ObraAuth={getSession:()=>current,logout,request};
async function start(){
 try{current=(await request('/api/me')).user;}catch{current=null;}
 const isDashboard=location.pathname.endsWith('dashboard.html');
 if(isDashboard){if(!current){location.replace('/index.html');return;}document.dispatchEvent(new Event('obra:ready'));return;}
 if(current){location.replace('/dashboard.html');return;}
 const form=$('auth-form');if(!form)return;
 let register=false;const message=$('auth-message');
 function mode(v){register=v;['name-field','confirm-field','role-field'].forEach(id=>$(id).classList.toggle('hidden',!v));$('login-tab').classList.toggle('active',!v);$('register-tab').classList.toggle('active',v);$('login-tab').setAttribute('aria-pressed',String(!v));$('register-tab').setAttribute('aria-pressed',String(v));$('auth-heading').textContent=v?'Crea tu cuenta':'Accede a tu espacio';$('auth-subtitle').textContent=v?'Elige tu rol y comienza a organizar tus proyectos.':'Bienvenida de nuevo. Tu espacio está listo para ti.';$('submit-auth').textContent=v?'Crear mi cuenta →':'Entrar a mi espacio →';$('password').autocomplete=v?'new-password':'current-password';message.textContent='';}
 $('login-tab').onclick=()=>mode(false);$('register-tab').onclick=()=>mode(true);
 form.addEventListener('submit',async e=>{e.preventDefault();message.textContent='';let email=$('email').value.trim().toLowerCase(),password=$('password').value;
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){message.textContent='Ingresa un correo válido.';return;}
 if(password.length<8){message.textContent='La contraseña debe tener al menos 8 caracteres.';return;}
 const values={email,password};if(register){values.name=$('full-name').value.trim();values.role=$('role').value;if(values.name.length<2){message.textContent='Escribe tu nombre completo.';return;}if(password!==$('confirm-password').value){message.textContent='Las contraseñas no coinciden.';return;}}
 const btn=$('submit-auth');btn.disabled=true;try{await request(register?'/api/register':'/api/login',{method:'POST',body:JSON.stringify(values)});location.replace('/dashboard.html');}catch(err){message.textContent=err.message;btn.disabled=false;}
 });
 }
 start();
})();
