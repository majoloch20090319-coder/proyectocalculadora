# ObraMetric Studio · Full Stack

Se conservó la identidad visual rosada y lavanda del proyecto enviado, con el HTML, CSS y JavaScript originales adaptados a un servidor Node.js. No requiere instalar paquetes de terceros.

## Ejecutar en Visual Studio Code

1. Descomprime la carpeta y ábrela en **Visual Studio Code** mediante Archivo → Abrir carpeta.
2. Instala Node.js 18 o superior, si todavía no lo tienes.
3. Abre **Terminal → Nueva terminal** y ejecuta `npm start` (o `node server.js`).
4. Visita **http://localhost:3000** en el navegador.
5. Regístrate como **Usuario** o **Administrador**. Al ingresar, verás tu rol. Si vuelves a abrir la dirección en el mismo navegador, la sesión se restaurará sin repetir el registro hasta que cierres sesión o pasen 30 días.

**Importante:** no abras `index.html` con doble clic ni uses Live Server para esta versión. Debes iniciar `server.js` porque ahora hay backend y base de datos del servidor.

## Funciones

- Usuarios y administradores con sesión persistente en cookie HttpOnly.
- El administrador dispone de un panel para consultar cuentas, roles y número de cálculos. Cada usuario gestiona solamente su propio historial.
- CRUD completo de cálculos (crear, consultar, editar y eliminar) y fórmulas validadas en backend.
- Almacenamiento en `data/database.json`, generado automáticamente al iniciar.
- Contraseñas cifradas con `scrypt` y sal individual; no se guardan en texto plano.
- Pruebas matemáticas: `npm test`.

## Observaciones

Esta es una implementación académica local. El registro como **Administrador** está abierto porque así se solicitó; en una instalación pública, el rol administrador debe asignarse por invitación o aprobación. Antes de publicarla en internet hacen falta HTTPS, base de datos transaccional, protección contra fuerza bruta y control de permisos más estricto.

Se respetaron los coeficientes suministrados, incluidos los valores de piedra en m² para vigas y columnas. Conviene verificar esas unidades con el docente porque para material pétreo normalmente se utiliza m³. En techo, el espesor es informativo porque la fórmula proporcionada calcula por m².
